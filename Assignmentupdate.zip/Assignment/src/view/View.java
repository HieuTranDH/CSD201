package view;

import model.SolarSystemObject;
import model.MassOrderedBST;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class View {

    public int displayMenuAndGetChoice(Scanner scanner) {
        System.out.println("\nSolar System Object Menu");
        System.out.println("1. Insert Object");
        System.out.println("2. Search Object(by mass)");
        System.out.println("3. Delete Object");
        System.out.println("4. Print All Objects");
        System.out.println("5. Access Object with Smallest and Largest Mass");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
        try {
            return scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid number.");
            scanner.nextLine();
            return -1;
        }
    }

    public SolarSystemObject[] getObjectDetails(Scanner scanner) {
        System.out.print("Enter object details (Name Mass EquatorialDiameter SemiMajorAxis OrbitalPeriod; separated): ");
        scanner.nextLine(); 
        String[] objectStrings = scanner.nextLine().split(";");
        List<SolarSystemObject> objects = new ArrayList<>();

        for (String objectString : objectStrings) {
            String[] details = objectString.trim().split(" ");
            if (details.length == 5) {
                try {
                    String objectName = details[0];
                    double objectMass = Double.parseDouble(details[1]);
                    double equatorialDiameter = Double.parseDouble(details[2]);
                    double semiMajorAxis = Double.parseDouble(details[3]);
                    double orbitalPeriod = Double.parseDouble(details[4]);
                    SolarSystemObject newObject = new SolarSystemObject(objectName, objectMass, equatorialDiameter,
                            semiMajorAxis, orbitalPeriod);
                    objects.add(newObject);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input for an object. Skipping.");
                }
            } else {
                System.out.println("Invalid input for an object. Skipping.");
            }
        }
        return objects.toArray(new SolarSystemObject[0]);
    }

    public double getMassToSearch(Scanner scanner) {
        System.out.print("Enter mass to search: ");
        return scanner.nextDouble();
    }

    public double getMassToDelete(Scanner scanner) {
        System.out.print("Enter mass to delete: ");
        return scanner.nextDouble();
    }

    public void displayObject(SolarSystemObject object) {
        if (object != null) {
            System.out.println("Object found: " + object);
        } else {
            System.out.println("Object not found.");
        }
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void displayAllObjects(MassOrderedBST solarSystemBST) {
        solarSystemBST.printAllObjects();
    }
}
