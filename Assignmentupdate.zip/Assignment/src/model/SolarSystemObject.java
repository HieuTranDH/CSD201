
package model;

public class SolarSystemObject {
    private String name;
    private double mass;
    private double equatorialDiameter;
    private double semiMajorAxis;
    private double orbitalPeriod;

    public SolarSystemObject(String name, double mass, double equatorialDiameter, double semiMajorAxis,
                             double orbitalPeriod) {
        this.name = name;
        this.mass = mass;
        this.equatorialDiameter = equatorialDiameter;
        this.semiMajorAxis = semiMajorAxis;
        this.orbitalPeriod = orbitalPeriod;
    }

    public double getMass() {
        return mass;
    }

    @Override
    public String toString() {
        return "Object Name: " + name +
                ", Mass: " + mass +
                ", Equatorial Diameter: " + equatorialDiameter +
                ", Semi-Major Axis: " + semiMajorAxis +
                ", Orbital Period: " + orbitalPeriod;
    }
}


