
package model;

public class MassOrderedBST {
    private Node root;

    public MassOrderedBST() {
        root = null;
    }

    public SolarSystemObject getMinMassObject() {
        if (root == null) {
            return null;
        }
        Node minNode = findMin(root);
        return (minNode != null) ? minNode.getObject() : null;
    }

    public SolarSystemObject getMaxMassObject() {
        if (root == null) {
            return null;
        }
        Node maxNode = findMax(root);
        return (maxNode != null) ? maxNode.getObject() : null;
    }

    public void printAllObjects() {
        System.out.println("\nAll Solar System Objects:");
        printInOrder(root);
    }

    public void insert(SolarSystemObject object) {
        root = insertNode(root, object);
    }

    public SolarSystemObject search(double mass) {
        return searchNode(root, mass);
    }

    public void delete(double mass) {
        root = deleteNode(root, mass);
    }

    private Node findMax(Node root) {
        while (root.getRight() != null) {
            root = root.getRight();
        }
        return root;
    }

    private Node insertNode(Node root, SolarSystemObject object) {
        if (root == null) {
            root = new Node(object);
            return root;
        }

        if (object.getMass() < root.getObject().getMass()) {
            root.setLeft(insertNode(root.getLeft(), object));
        } else if (object.getMass() > root.getObject().getMass()) {
            root.setRight(insertNode(root.getRight(), object));
        }

        return root;
    }

    private Node findMin(Node root) {
        while (root.getLeft() != null) {
            root = root.getLeft();
        }
        return root;
    }

    private void printInOrder(Node root) {
        if (root != null) {
            printInOrder(root.getLeft());
            System.out.println(root.getObject());
            printInOrder(root.getRight());
        }
    }

    private SolarSystemObject searchNode(Node root, double mass) {
        if (root == null || root.getObject().getMass() == mass) {
            return (root != null) ? root.getObject() : null;
        }

        if (mass < root.getObject().getMass()) {
            return searchNode(root.getLeft(), mass);
        } else {
            return searchNode(root.getRight(), mass);
        }
    }

    private Node deleteNode(Node root, double mass) {
        if (root == null) {
            return root;
        }
        if (mass < root.getObject().getMass()) {
            root.setLeft(deleteNode(root.getLeft(), mass));
        } else if (mass > root.getObject().getMass()) {
            root.setRight(deleteNode(root.getRight(), mass));
        } else {
            if (root.getLeft() == null) {
                return root.getRight();
            } else if (root.getRight() == null) {
                return root.getLeft();
            }

            root.setObject(findMin(root.getRight()).getObject());

            root.setRight(deleteNode(root.getRight(), root.getObject().getMass()));
        }

        return root;
    }

    private static class Node {
        private SolarSystemObject object;
        private Node left;
        private Node right;

        public Node(SolarSystemObject object) {
            this.object = object;
            this.left = null;
            this.right = null;
        }

        public SolarSystemObject getObject() {
            return object;
        }

        public Node getLeft() {
            return left;
        }

        public Node getRight() {
            return right;
        }

        public void setLeft(Node left) {
            this.left = left;
        }

        public void setRight(Node right) {
            this.right = right;
        }

        public void setObject(SolarSystemObject object) {
            this.object = object;
        }
    }
}
