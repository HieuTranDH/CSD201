// Main class
import controller.SolarSystemController;
import model.MassOrderedBST;
import view.View;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        MassOrderedBST solarSystemBST = new MassOrderedBST();
        View view = new View();
        SolarSystemController controller = new SolarSystemController(solarSystemBST, view);
        Scanner scanner = new Scanner(System.in);
        controller.getUserInput(scanner);
        scanner.close();
    }
}
