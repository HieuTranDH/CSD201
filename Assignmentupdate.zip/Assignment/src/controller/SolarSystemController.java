package controller;

import model.MassOrderedBST;
import model.SolarSystemObject;
import view.View;

import java.util.Scanner;

public class SolarSystemController {
    private MassOrderedBST solarSystemBST;
    private View view;

    public SolarSystemController(MassOrderedBST solarSystemBST, View view) {
        this.solarSystemBST = solarSystemBST;
        this.view = view;
    }

    public void getUserInput(Scanner scanner) {
        int choice;
        do {
            choice = view.displayMenuAndGetChoice(scanner);
            switch (choice) {
                case 1:
                    insertObject(scanner);
                    break;
                case 2:
                    searchObject(scanner);
                    break;
                case 3:
                    deleteObject(scanner);
                    break;
                case 4:
                    view.displayAllObjects(solarSystemBST);
                    break;
                case 5:
                    accessMinMaxObjects();
                    break;
                case 6:
                    view.displayMessage("Exiting program.");
                    break;
                default:
                    view.displayMessage("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private void insertObject(Scanner scanner) {
        SolarSystemObject[] objects = view.getObjectDetails(scanner);
        for (SolarSystemObject object : objects) {
            if (object != null) {
                solarSystemBST.insert(object);
                view.displayMessage("Object inserted successfully: " + object);
            }
        }
    }

    private void searchObject(Scanner scanner) {
        double searchMass = view.getMassToSearch(scanner);
        SolarSystemObject foundObject = solarSystemBST.search(searchMass);
        view.displayObject(foundObject);
    }

    private void deleteObject(Scanner scanner) {
        double deleteMass = view.getMassToDelete(scanner);
        solarSystemBST.delete(deleteMass);
        view.displayMessage("Object deleted successfully.");
    }

    private void accessMinMaxObjects() {
        SolarSystemObject minMassObject = solarSystemBST.getMinMassObject();
        view.displayMessage("Object with the smallest mass: " + minMassObject);

        SolarSystemObject maxMassObject = solarSystemBST.getMaxMassObject();
        view.displayMessage("Object with the largest mass: " + maxMassObject);
    }
}
