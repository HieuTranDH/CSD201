package CircularLinkedList;

import java.util.Scanner;

class Player {
    String playerName;

    public Player(String playerName) {
        this.playerName = playerName;
    }
}

class Node {
    Player player;
    Node next;

    public Node(Player player) {
        this.player = player;
        this.next = null;
    }
}

class GameQueue {
    private Node front;
    private Node rear;

    public GameQueue() {
        front = null;
        rear = null;
    }

    //check hàng chờ có trống hay không
    public boolean isEmpty() {
        return front == null;
    }

    //Thêm người chơi vào hàng chờ vào cuối hàng
    public void enqueue(Player player) {
        Node newNode = new Node(player);

        if (isEmpty()) {
            front = newNode;
        } else {
            rear.next = newNode;
        }

        rear = newNode;
        rear.next = front;
    }

    //Xóa và di chuyển người chơi lên đầu hàng
    public Player dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return null;
        }

        Player removedPlayer = front.player;
        front = front.next;

        if (front == null) {
            rear = null;
        } else {
            rear.next = front;
        }

        return removedPlayer;
    }

    //Hiển thị toàn bộ người chơi
    public void displayQueue() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        Node current = front;
        do {
            System.out.print(current.player.playerName + " ");
            current = current.next;
        } while (current != front);

        System.out.println();
    }
}

public class MultiPlayerGameQueue {
    public static void main(String[] args) {
        GameQueue gameQueue = new GameQueue();
        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            System.out.println("1. Join Player to Queue");
            System.out.println("2. Leave Player from Queue");
            System.out.println("3. Display Queue");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter player name to join: ");
                    String playerName = scanner.next();
                    gameQueue.enqueue(new Player(playerName));
                    System.out.println(playerName + " joined the queue.");
                    break;
                case 2:
                    Player removedPlayer = gameQueue.dequeue();
                    if (removedPlayer != null) {
                        System.out.println(removedPlayer.playerName + " left the queue.");
                    }
                    break;
                case 3:
                    System.out.println("Current Queue:");
                    gameQueue.displayQueue();
                    break;
                case 0:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 0);

        scanner.close();
    }
}

